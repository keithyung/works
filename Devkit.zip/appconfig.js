
module.exports = {
	os:(String(process.env.OS).toLowerCase().indexOf('windows')!=-1)?'windows':'other'
	,basepath: __dirname
	,bin_path: __dirname+'/bin' 
	,approot_path: __dirname+'/approot' //web 根目录
	,lib_path: __dirname+'/lib'
	,upfile_tmp: __dirname+'/tmp' //上传临时文件存放目录
	,host:'127.0.0.1' //本地 host
	,port:10012 //端口号
	,autogrunt:false //是否自动执行 grunt
	,autoreload:true //是否启动自动刷新
}
