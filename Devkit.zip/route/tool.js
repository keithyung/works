
var appconfig=require('../appconfig');
var querystring=require('querystring');
var http=require('http');
var https=require('https');
var sys=require('util');
var url=require('url');
var fs=require('fs');
var fs_ext=require('fs-extra');
var km_cl=require('../lib/km_cl');
var parsepara=require('../lib/parsepara');
var http_ext=require('../lib/http_post');

var km_cmdlist={};

module.exports={
	init:function (_app){

		_app.get('/', function(req, res){
			var s='Welcome to FEDLab Devkit!';
		    res.send(s);
		});

		_app.get('/vendor/livereload.js', function(req, res){
			var rs=String(fs.readFileSync(appconfig.basepath+'/lib/livereload.js'));
		    res.writeHead(200, {'content-type': 'application/javascript'});
		    res.write(rs);
		    res.end();
		});

		_app.get('/snapshot', function(req, res){

		    var km_cmdlist=new km_cl();
		    km_cmdlist.cmdA=[];
		    km_cmdlist.cmdA.push({func:function (){
		        km_cmdlist.doCmdA();
		    }});
		    km_cmdlist.cmdA.push({func:function (){
		        res.send('ok');
		        km_cmdlist.doCmdA();
		    }});
		    
		    km_cmdlist.cmdI=0;
		    km_cmdlist.doCmdA();
		});
	}
};

