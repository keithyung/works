
var http=require('http');
var https=require('https');
var sys=require('util');
var url=require('url');
var fs=require('fs');
var fs_ext=require('fs-extra');
var cp=require('child_process');
var path_module=require('path');
var url=require('url');
var express=require('express');
var app=express();
var router = express.Router();
var multer=require('multer');
var bodyParser = require('body-parser');
var cookieParser = require('cookie-parser');
var session = require('express-session');
var methodOverride = require('method-override');
var errorhandler = require('errorhandler');
var serveStatic = require('serve-static');
var connect=require('connect');
var localStorage=require('localStorage');
var play = require('play');

var emoji = require('emoji');
var colors = require('colors/safe');
colors.setTheme({
    silly: 'rainbow',
    input: 'grey',
    verbose: 'cyan',
    prompt: 'grey',
    info: 'green',
    data: 'grey',
    help: 'cyan',
    warn: 'yellow',
    debug: 'blue',
    error: 'red',
    link: ['underline', 'blue']
});

var appconfig=require('./appconfig');
var km_cl=require('./lib/km_cl');
var parsepara=require('./lib/parsepara');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(multer({ dest: appconfig.upfile_tmp+'/'}));

app.use(cookieParser());
app.use(errorhandler());

var allowCrossDomain=function(req, res, next) {
    res.removeHeader("X-Powered-By");
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    next();
}
app.use(methodOverride());
app.use(allowCrossDomain);
app.use(serveStatic(appconfig.approot_path));

require('./route/tool').init(app);

process.on('uncaughtException',function(e){
    sys.log(e.stack);
});

require('./lib/watchfolder.js');
app.listen(appconfig.port);
if(appconfig.os!='windows'){
    console.log('😎 😎 😎');
    play.sound(__dirname+'/sounds/Ping.aiff');
}
console.log(colors.info('Listening on ') + colors.underline('http://127.0.0.1:' + appconfig.port));

if(appconfig.autoreload){
	var livereload=require('livereload');
	server=livereload.createServer();
	server.watch(__dirname+'/approot');
}
