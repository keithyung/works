module.exports = function(grunt) {

    grunt.initConfig({

        pkg: grunt.file.readJSON('package.json'),
        proto_setup: {
            appserverupdate_path: '',
            app: {
                name: ''
            }
        },

        //https://github.com/gruntjs/grunt-contrib-jshint
        jshint: {
            all: ['approot/**/index.js']
        },

        less: {
            'page1': {
                options: {
                    cleancss:true
                },
                files: {
                    "approot/page1/css/style.css": "approot/page1/css/style.less"
                }
            }
        },

        //https://github.com/gruntjs/grunt-contrib-csslint
        csslint: {
            lax: {
                options: {
                    "import": false,
                    "box-sizing": false,
                    "box-model": false,
                    "adjoining-classes": false,
                    "qualified-headings": false,
                    "important": false,
                    "vendor-prefix": false,
                    "star-property-hack": false
                },
                src: ['approot/**/style.css']
            }
        }

    });

    /*
    grunt.loadNpmTasks('grunt-string-replace');
    grunt.loadNpmTasks('grunt-contrib-clean');
    grunt.loadNpmTasks('grunt-contrib-concat');
    grunt.loadNpmTasks('grunt-contrib-cssmin');
    grunt.loadNpmTasks('grunt-contrib-imagemin');
    grunt.loadNpmTasks('grunt-contrib-uglify');
    grunt.loadNpmTasks('grunt-shell');
    grunt.loadNpmTasks('grunt-jsbeautifier');
    */

    grunt.loadNpmTasks('grunt-contrib-jshint');
    grunt.loadNpmTasks('grunt-contrib-csslint');
    grunt.loadNpmTasks('grunt-contrib-less');

    grunt.registerTask('mycsslint', [
        'csslint'
    ]);

    grunt.registerTask('myjshint', [
        'jshint'
    ]);

};