# Devkit 使用说明

## 安装

  1. 下载 nodejs http://nodejs.org
  
  2. 安装 grunt，在终端中执行 `npm install -g grunt-cli`
  
  3. 下载并解压 [Devkit.zip]()
  
  4. 安装开发包: mac 下在终端中进入Devkit 目录，执行 `npm install`；windows 下运行 `install-win.bat`

## 运行

mac 下运行 `node-start`；windows 下运行 `node-start-win.bat`

## 文件说明

### approot

WEB 服务器根目录

## route

NodeJS 路由模块

## bin

命令行工具

## lib

NodeJS 库

* psdprase.js PSD文件解析（Todo）
* watchfolder.js 监视文件夹和文件变化
* dogrunt.js 执行 grunt 命令

## tmp

上传临时文件

## app.js

NodeJS 起始文件

## appconfig.js

环境配置文件

```
module.exports = {
	os:(String(process.env.OS).toLowerCase().indexOf('windows')!=-1)?'windows':'other'
	,basepath: __dirname
	,bin_path: __dirname+'/bin' 
	,approot_path: __dirname+'/approot' //web 根目录
	,lib_path: __dirname+'/lib'
	,upfile_tmp: __dirname+'/tmp' //上传临时文件存放目录
	,host:'127.0.0.1' //本地 host
	,port:10012 //端口号
	,autogrunt:false //是否自动执行 grunt
	,autoreload:true //是否启动自动刷新
}
```

## Gruntfile.js

grunt 配置文件

## package.json

项目配置文件
